
package com.full.demo;

import static java.lang.System.out;

public class MainController extends AbstractMyString {

	/**
	 * 
	 * @author Subbulakshmi
	 * @category Assignment #1 - MyString Demo
	 *
	 */
	String a = "";

	public MainController(String str) {
		this.theString = str;
	}

	public String reverse() {

		for (int i = theString.length() - 1; i >= 0; i--) {
			a = a + theString.charAt(i);

		}
		return a;
	}

	public int getVowelsCount() {

		int count = 0;
		for (int i = 0; i < theString.length(); i++) {
			char ch = theString.charAt(i);
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I'
					|| ch == 'O' || ch == 'U') {
				count++;
			}
		}

		return count;
	}

	public int getConsonantCount() {

		int count = 0;
		int consonant = 0;
		for (int i = 0; i < theString.length(); i++) {
			char ch = theString.charAt(i);
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I'
					|| ch == 'O' || ch == 'U') {
				count++;
			} else if (ch != ' ') {

				consonant++;
			}
		}

		return consonant;

	}

	public int getNumCapitalLetters() {

		int count = 0;
		char[] c = theString.toCharArray();
		char[] c1 = theString.toUpperCase().toCharArray();

		for (int i = 0; i < theString.length(); i++) {

			if (c[i] == c1[i]) {

				count++;
			}

		}
		return count;

	}

	public int getLength() {

		int b = theString.length();
		return b;
	}

	public int getSumOfAllCharacters() {

		int sum = 0;
		for (char ch : theString.toCharArray()) {
			if (ch >= 'a' && ch <= 'z') {
				sum += 1 + ch - 'a';
			}
		}
		return sum;
	}

	public static void main(String args[]) {
		// TODO: Test code goes here
		MainController a = new MainController("HelloWorld");

		String b1 = a.reverse();
		System.out.println("Reverse String: " + b1);

		int b = a.getVowelsCount();
		System.out.println("Number of vowels: " + b);

		int c = a.getConsonantCount();
		System.out.println("Number of consonants: " + c);

		int d = a.getNumCapitalLetters();
		System.out.println("Number of Capital Letters: " + d);

		int e = a.getLength();
		System.out.println("Length of the String: " + e);

		int g = a.getSumOfAllCharacters();
		System.out.println("Sum of All the Characters: " + g);
	}
}
