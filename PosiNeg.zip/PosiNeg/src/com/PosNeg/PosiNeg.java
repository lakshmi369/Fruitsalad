package com.PosNeg;

public class PosiNeg {







	/*public PosNeg() {

	}*/

	public static boolean posNeg(int a, int b, boolean result) {
		
		if ((a > 0 && b < 0) || result == false) {
			return true;
		} else if ((a < 0 && b > 0) || result == false) {
			return true;
		} else if ((a > 0 && b > 0) || result == false) {
			return true;
		} else if ((a < 0 && b < 0) || result == false) {

			return true;

		}

		return false;

	}

	public static void main(String ar[]) {

		// Test #1

		int x = 1;
		int y = -1;
		boolean value = false;

		value = PosiNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("Test pass");

		} else {
			System.out.println("fails");
		}

		// Test #2

		x = 1;
		y = 1;
		value = false;

		value = PosiNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("Test pass");

		} else {
			System.out.println("fails");
		}

		// Test #3

		x = -1;
		y = -1;

		value = false;

		value = PosiNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("Test pass");
		} else {
			System.out.println("fails");
		}

		// Test #4

		x = -1;
		y = -1;

		value = true;

		value = PosiNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("Test pass");
		} else {
			System.out.println("fails");
		}

		// Test #5

		x = -1;
		y = 1;

		value = true;

		value = PosiNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("Test pass");
		} else {
			System.out.println("fails");
		}
		// Test #6

		x = 1;
		y = 1;

		value = true;

		value = PosiNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("Test pass");
		} else {
			System.out.println("fails");
		}

	}

}






