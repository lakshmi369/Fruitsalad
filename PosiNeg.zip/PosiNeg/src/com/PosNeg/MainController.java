package com.PosNeg;
	

import java.util.Scanner;

public class MainController {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("User can give the input ");

		
		int a = 0;

		System.out.print("Enter a: ");
		a = sc.nextInt();

		System.out.print("Enter b: ");
		int b = sc.nextInt();

		boolean val = false;
		System.out.print("Boolean Value:");
		val = sc.nextBoolean();

		if (PosiNeg.posNeg(a, b, val)) {
			System.out.println("The result is TRUE");
		}

		sc.close();
	}

}

