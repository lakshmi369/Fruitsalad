package com.StringComparision;

public class StringBufferConcat {

	public void getConcat() {

		StringBuffer sb = new StringBuffer("hai ");

		for (int i = 0; i < 100000; i++) {
			StringBuffer s = sb.append(" Hello");
		}

	}

}
