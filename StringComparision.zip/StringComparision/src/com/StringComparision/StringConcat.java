package com.StringComparision;

public class StringConcat {

	public void getConcat() {

		String a = new String("hello");

		for (int i = 0; i < 100000; i++) {
			String st = a.concat("hi");

		}
	}

}
