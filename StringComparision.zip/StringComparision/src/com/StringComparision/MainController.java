package com.StringComparision;

public class MainController {

	public static void main(String args[]) {

		// for string builder
		long start = System.currentTimeMillis();
		StringBuilderConcat s = new StringBuilderConcat();
		s.getConcat();
		long stop = System.currentTimeMillis();
		long total = stop - start;
		System.out.println("Total time for StringBuilder: " + total);

		// for string
		long on = System.currentTimeMillis();
		StringConcat s1 = new StringConcat();
		s1.getConcat();
		long off = System.currentTimeMillis();
		long diff = off - on;
		System.out.println("Total time for String: " + diff);

		// for string buffer
		long a = System.currentTimeMillis();
		StringBufferConcat s2 = new StringBufferConcat();
		s2.getConcat();
		long b = System.currentTimeMillis();
		long c = b - a;
		System.out.println("Total time for StringBuffer: " + c);
	}

}
