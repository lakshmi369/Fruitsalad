package com.StringComparision;

public class StringBuilderConcat {

	public void getConcat() {

		StringBuilder s = new StringBuilder("hai ");

		for (int i = 0; i < 100000; i++) {
			StringBuilder str = s.append(" hello");
		}
	}
}
