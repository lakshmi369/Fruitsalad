package com.Pos;

public class Pos {

	public static boolean posNe(int x, int y, boolean result) {
		if ((x > 0 && y < 0) && (result == false)) {
			return true;
		} else if ((x < 0 && y > 0) && (result == false)) {
			return true;
		}  else if ((x < 0 && y < 0) && (result == true)) {
			return true;
		} 
		return false;
	}

	public static void main(String args[]) {

		boolean store = false;

		// Test 1

		store = Pos.posNe(1, -1, false);

		if (store == true) {
			System.out.println("1.Test pass");
		} else {
			System.out.println("1.Fails");
		}

		// Test 2

		store = Pos.posNe(-1, 1, false);

		if (store == true) {
			System.out.println("2.Test pass");
		} else {
			System.out.println("2.Fails");
		}

		// Test 3

		store = Pos.posNe(1, 1, false);

		if (store == false) {
			System.out.println("3.Test pass");
		} else {
			System.out.println("3.Fails");
		}

		// Test 4

		store = Pos.posNe(-1, -1, false);

		if (store == false) {
			System.out.println("4.Test pass");
		} else {
			System.out.println("4.Fails");
		}

		// Test 5

		store = Pos.posNe(1, -1, true);

		if (store == false) {
			System.out.println("5.Test pass");
		} else {
			System.out.println("5.Fails");
		}

		// Test 6

		store = Pos.posNe(-1, 1, true);

		if (store == false) {
			System.out.println("6.Test pass");
		} else {
			System.out.println("6.Fails");
		}
		// Test 7

		store = Pos.posNe(-1, -1, true);

		if (store == true) {
			System.out.println("7.Test pass");
		} else {
			System.out.println("7.Fails");
		}

		// Test 8

		store = Pos.posNe(1, 1, true);

		if (store == false) {
			System.out.println("8.Test pass");
		} else {
			System.out.println("8.Fails");
		}

	}
}
