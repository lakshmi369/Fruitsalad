package com.Pos;
import java.util.Scanner;

public class MainTestController {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("User can give the input ");

		// System.out.println("Enter b:");
		int a = 0;

		System.out.print("Enter a: ");
		a = sc.nextInt();

		System.out.print("Enter b: ");
		int b = sc.nextInt();

		boolean val ;
		System.out.print("Boolean Value:");
		val = sc.nextBoolean();
		boolean st=Pos.posNe(a, b, val);

		if (st==true) {
			System.out.println("The result is TRUE");
		}
		else
		{
			System.out.println("The result is FALSE");
		}

		sc.close();
	}

}
