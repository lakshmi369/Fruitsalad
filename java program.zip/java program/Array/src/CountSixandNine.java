import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CountSixandNine {

	/*public int countSix(List<Integer> list) {
		int res = 0;
		int index;
		int count = 0;

		for (index = 0; index < list.size(); index++) {
			res = list.get(index);
			if (res == 6) {
				count++;
			}else if(res == 9){
				count++;
			}
			
		}

		return count;
	}
*/
	/*public int countNine(List<Integer> list) {
		int res = 0;
		int index;
		int count = 0;

		for (index = 0; index < list.size(); index++) {
			res = list.get(index);
			if (res == 9) {
				count++;
			}
		}

		return count;
	} 
*/
	
	
	public int getCount(List<Integer> list, int number) {
		int countOfNumber = 0;

		for (int i = 0; i < list.size(); i++) {

		int value = list.get(i);

		if (value == number) {

		countOfNumber++;
		}
		}

		return countOfNumber;
		}
	public static void main(String args[]) {

		Integer[] val = new Integer[] { 2, 9, 7, 6, 6, 6, 4, 6, 6, 6, 6, 8, 6, 9, 9, 7, 9, 6, 6 };
		ArrayList<Integer> ar = new ArrayList<Integer>(Arrays.asList(val));

		CountSixandNine num = new CountSixandNine();
		int a = num.getCount(ar,6);
		int b = num.getCount(ar,9);

		if (a == 10 && b==4) {
			System.out.println("Test pass");
		} else {
			System.out.println("Test fails");
		}

	}
}