import java.util.ArrayList;

public class MainController {

	
	

	public static void main(String args[]) {
		long start=System.currentTimeMillis();

		
		// Generating RandomNumbers
		ArrayList<Integer> list = new ArrayList<Integer>();
		RandomNumber.ran(list);

		// Creating object for the class that contains count 6's and 9's method
		CountSixandNine a = new CountSixandNine();
		int countsix = a.getCount(list,6);
		System.out.println("Number of six's: " + countsix);
		int countnine = a.getCount(list,9);
		System.out.println("Number of Nine's: " + countnine);

		// Creating object for the class that contains consecutive 6's and 9's
		// method
		ConsecutiveSixandNine c = new ConsecutiveSixandNine();
		int consecsix = c.consecNumbers(list,6);
		System.out.println("Number of 6's: " + countsix + " Number of consecutive 6's: " + consecsix);
		int consecnine = c.consecNumbers(list,9);
		System.out.println("Number of 9's: " + countnine + " Number of consecutive 9's: " + consecnine);
     
		long stop=System.currentTimeMillis();
		long total=stop-start;
		
		System.out.println("Total Milliseconds to run a program : "+total);
		
	}
	
}
