import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class RandomNumber {

	public static final int MAX = 100;
	public static final int MIN = 1;
	public static final int SIZE = 10000000;

	// Method to Generate Random Numbers

	public static void ran(ArrayList<Integer> list) {

		for (int i = MIN; i <= SIZE; i++) {

			int randomNum = ThreadLocalRandom.current().nextInt(MIN, MAX + 1);
			list.add(randomNum);
		}
	}

	// Method To Check the range of the random numbers between 0 and 100

	public boolean range(ArrayList<Integer> list) {
		for (int j = 0; j < list.size(); j++) {
			boolean isRange = false;
			int range = list.get(j);
			if (range >= MIN && range <= MAX) {
				isRange = true;
			} else {
				System.out.println("Test range fails");
				isRange = false;

			}
		}
		return true;
	}

	public static void main(String args[]) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		RandomNumber.ran(list);

		// Test Case 1:

		if (list.size() == SIZE) {
			System.out.println("Test Pass");
		} else {
			System.out.println("Test fails");
		}

		// Test case 2:

		RandomNumber r = new RandomNumber();
		boolean a = r.range(list);
		if (a == true) {
			System.out.println("Test range pass");
		} else {
			System.out.println("Test range Fails");
		}

	}
}
