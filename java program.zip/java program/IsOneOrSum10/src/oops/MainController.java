
/*
subbulakshmi
05 May 2017
IsOneorSum10
 
 */
package oops;

import java.util.Scanner;

public class MainController {

	public static boolean isOneOrSum10(int a, int b) {

		if (a + b == 10) {
			return true;
		} else if (a == 10 || b == 10) {
			return true;
		} else {
			return false;
		}

	}

	public static void main(String args[]) {

		int a = 0;
		int b = 0;

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a:");
		a = scan.nextInt();
		System.out.print("Enter b:");
		b = scan.nextInt();
		boolean result = false;

		result = MainController.isOneOrSum10(a, b);

		if (result == true) {
			System.out.println("Test Pass 	a: " + a + " b: " + b);
		} else if(result==false) {
			System.out.println("Test Pass 	a: " + a + " b " + b);
		}

		scan.close();
	}

}
