/*
subbulakshmi
05 May 2017
IsOneorSum10
 
 */

package oops;

public class IsOneOrSum10 {

	public static boolean isOneOrSum10(int a, int b) {

		if (a + b == 10) {
			return true;
		} else if (a == 10 || b == 10) {
			return true;
		} else {
			return false;
		}

	}

	public static void main(String args[]) {
		int a = 0;
		int b = 0;

		// Test 1
		a = 1;
		b = 9;
		boolean result = false;

		result = IsOneOrSum10.isOneOrSum10(a, b);

		if (result == true) {
			System.out.println("Test Pass 	a:" + a + " b:" + b);
		} else {
			System.out.println("Test Fails 	a:" + a + " b" + b);
		}

		// Test 2

		a = 9;
		b = 9;

		result = IsOneOrSum10.isOneOrSum10(a, b);

		if (result == false) {
			System.out.println("Test Pass 	a:" + a + " b:" + b);
		} else {
			System.out.println("Test Fails 	a:" + a + " b:" + b);
		}

		// Test 3

		a = 9;
		b = 10;

		result = IsOneOrSum10.isOneOrSum10(a, b);

		if (result == true) {
			System.out.println("Test Pass 	a:" + a + " b:" + b);
		} else {
			System.out.println("Test Fails 	a:" + a + " b" + b);
		}

	}

}
