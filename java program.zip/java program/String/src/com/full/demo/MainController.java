
package com.full.demo;

import static java.lang.System.out;

public class MainController extends AbstractMyString {

	/**
	 * 
	 * @author YOUR_NAME_HERE
	 * @category Assignment #1 - MyString Demo
	 *
	 */
	public String str = "HelloAll";
	String a = "";

	public String reverse() {

		for (int i = str.length() - 1; i >= 0; i--) {
			a = a + str.charAt(i);

		}
		return a;
	}

	public int getVowelsCount() {

		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I'
					|| ch == 'O' || ch == 'U') {
				count++;
			}
		}

		return count;
	}

	public int getConsonantCount() {

		int count = 0;
		int consonant = 0;
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I'
					|| ch == 'O' || ch == 'U') {
				count++;
			} else if (ch != ' ') {

				consonant++;
			}
		}

		return consonant;

	}

	public int getNumCapitalLetters() {

		int count = 0;
		char[] c = str.toCharArray();
		char[] c1 = str.toUpperCase().toCharArray();

		for (int i = 0; i < str.length(); i++) {

			if (c[i] == c1[i]) {

				count++;
			}

		}
		return count;

	}

	public int getLength() {

		int b = str.length();
		return b;
	}

	public int getSumOfAllCharacters() {

		int sum = 0;
		for (char ch : str.toCharArray()) {
			if (ch >= 'a' && ch <= 'z') {
				sum += 1 + ch - 'a';
			}
		}
		return sum;
	}

	public static void main(String args[]) {
		// TODO: Test code goes here
		MainController a = new MainController();

		String b1 = a.reverse();
		System.out.println("Reverse String: "+b1);

		// Test case for counting vowels
		int b = a.getVowelsCount();
		System.out.println("Number of vowels: " + b);

		// Test case for counting consonant
		int c = a.getConsonantCount();
		System.out.println("Number of consonants: " + c);

		// Test case for counting UPPERCASE
		int d = a.getNumCapitalLetters();
		System.out.println("Number of Capital Letters: " + d);

		// Test case for counting the length
		int e = a.getLength();
		System.out.println("Length of the String: " + e);

		// Test case for getting sum of all the characters
		int g = a.getSumOfAllCharacters();
		System.out.println("Sum of All the Characters: " + g);
	}
}
