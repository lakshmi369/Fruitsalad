import java.util.Scanner;

public class MainTestController {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("User can give the input ");

		// System.out.println("Enter b:");
		int a = 0;

		System.out.print("Enter a: ");
		a = sc.nextInt();

		System.out.print("Enter b: ");
		int b = sc.nextInt();

		boolean val = false;
		System.out.print("Boolean Value:");
		val = sc.nextBoolean();

		if (PosNeg.posNeg(a, b, val)) {
			System.out.println("The result is TRUE");
		}

		sc.close();
	}

}
