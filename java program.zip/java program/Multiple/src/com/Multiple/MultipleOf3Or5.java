package com.Multiple;

public class MultipleOf3Or5 {

	public boolean multipleOf3Or5Only(int num) {
		if (num % 5 == 0 && num % 3 == 0) {
			return false;
		} else if (num % 5 == 0 || num % 3 == 0) {
			return true;
		}

		return false;
	}

	public static void main(String args[]) {

		MultipleOf3Or5 s = new MultipleOf3Or5();

		// Test case for multiple of 5
		int n = 50;
		boolean b = s.multipleOf3Or5Only(n);
		if (b == true) {
			System.out.println("MultipleOf3Or5Only(" + n + ") --> True");
		} else {
			System.out.println("Not a multiple of 3 or 5");
		}

		// Test case for multiple of 3
		int x = 27;
		boolean c = s.multipleOf3Or5Only(x);
		if (c == true) {
			System.out.println("MultipleOf3Or5Only(" + x + ") --> True");
		} else {
			System.out.println("Not a multiple of 3 or 5");
		}

		// Test case for multiple of 3 and 5
		int y = 60;
		boolean d = s.multipleOf3Or5Only(y);
		if (d == false) {
			System.out.println("MultipleOf3Or5Only(" + y + ") --> False");
		} else {
			System.out.println("Not a multiple of 3 or 5");
		}
		
		// Test case for multiple of 3 and 5
				int z = 61;
				boolean e = s.multipleOf3Or5Only(z);
				if (e == false) {
					System.out.println("MultipleOf3Or5Only(" + z + ") --> False");
				} else {
					System.out.println("Not a multiple of 3 or 5");
				}

	}

}
