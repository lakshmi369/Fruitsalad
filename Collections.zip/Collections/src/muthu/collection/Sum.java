package muthu.collection;
import java.util.ArrayList;
import java.util.Arrays;

import java.util.List;

public class Sum {

	public int sumOf5(List<Integer> list) {
		// Iterator<Integer> iter=list.iterator();
		int res = 0;
		int index = 0;
		// int thisiter=iter.next();
		for (index = 0; index < list.size(); index++) {
			if (index % 5 == 0) {
				res += list.get(res);
			}
		}

		return res;
	}

	public static void main(String args[]) {

		Integer[] a = new Integer[] { 1, 3, 5, 7, 9, 6, 5, 7 };
		ArrayList<Integer> arr = new ArrayList<Integer>(Arrays.asList(a));
		Sum sum = new Sum();
		int x = sum.sumOf5(arr);
		if (x == 4) {
			System.out.println("Test pass");
		} else {
			System.out.println("Test fails");
		}
	}

}
