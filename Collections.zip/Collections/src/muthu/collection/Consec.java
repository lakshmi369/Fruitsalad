package muthu.collection;

import java.util.ArrayList;
import java.util.Arrays;

public class Consec {
	

	public int con(ArrayList<Integer> list){
	         int n = list.size(), count=0,noofconsecutives=0, searchElement=6;
	         boolean isConsecutiveBreak = true;
	         for(int i=0;i<list.size();i++) {
	             if (list.get(i) == searchElement) {
	                 count += 1;
	             }
	             
	             if(list.get(i)  == searchElement && i+1 < n && list.get(i+1) == searchElement) {
	                 noofconsecutives += isConsecutiveBreak ? 2 : 1;
	                 isConsecutiveBreak = false;
	             } else {
	                 isConsecutiveBreak = true;
	             }
	         }
	         System.out.println(count+" "+searchElement+"'s "+noofconsecutives+" consecutive "+searchElement+"'s");
	     
	return noofconsecutives;
	}
	

	 	
	

public static void main(String args[])
{
	Integer[] val = new Integer[] { 2, 9, 7, 6, 6, 6, 4, 6, 6, 6, 6, 8, 6, 9, 9, 7, 9, 6, 6 };
	ArrayList<Integer> ar = new ArrayList<Integer>(Arrays.asList(val));
	Consec num = new Consec();
	//boolean a=false;
	int a=num.con(ar);
	if(a==9){
		System.out.println("Test pass");
	}else
	{
		System.out.println("Test Fails");
	}

}}

	
	
	



