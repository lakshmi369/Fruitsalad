package muthu.collection;

public class Test {
	public static void main(String args[]){

	int[] a={1,4,6,6,6,7,8,6,6,};
	int search=6;
	int consec=0;
	//int count=0;
	int n=a.length;
	
	for(int i=0;i<n;i++)
	{
		
		if((a[i]==search) &&( a[i+1])==search)
		{
			consec+=consec==0?2:1;
			consec++;
			System.out.println(consec);
		}
	}
	
}}
