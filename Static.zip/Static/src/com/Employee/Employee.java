package com.Employee;

import java.util.Scanner;

public class Employee {

	public static  int WORKING_HOURS_PER_WEEK = 40;
	private static int a;

	public static void setWorkingHours(int a) {

		if (a < WORKING_HOURS_PER_WEEK) {

			a = WORKING_HOURS_PER_WEEK - a;
			System.out.println("Sorry you need to work " + a + " hours more for a week" );

		} else if (a > WORKING_HOURS_PER_WEEK && a < 90) {

			a = a - WORKING_HOURS_PER_WEEK;
			System.out.println("Wow! worked more than " + a + " hours.You will get a bonus of " + a + " Points");
		} else {
			System.out.println("No cheating!!! you can't work for " + a + " hours a week");
		}
	}

	public static void main(String args[]) {

		Scanner inp = new Scanner(System.in);
		System.out.print("Hey all! Enter the working hours to know your status of the week :");
		a = inp.nextInt();

		Employee.setWorkingHours(a);

		inp.close();
		
	
	}

}
