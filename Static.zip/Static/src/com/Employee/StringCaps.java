package com.Employee;

public class StringCaps {

	static String s="HEllo World";
	/*public StringCaps(String a)
	{
		StringCaps.s=a;
	}*/
	
	public int getCap(){
		
		char[] st=s.toUpperCase().trim().toCharArray();
		//System.out.println(st);
		//System.out.println(s);
		int count=0;
		char[] s1=s.toCharArray();
		
	for(int i=0;i<s.length();i++){
		if(s1[i]==st[i]){
			count++;
			//System.out.println(count);
		}}
		return count;
	}
	
	
	public static void main(String args[])
	{
		StringCaps str=new StringCaps();
		int res=str.getCap();
		System.out.println(res);
	}
	
}
