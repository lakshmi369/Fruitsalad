package com.Employee;

public class Sample {

     private int age;
     
     public Sample(){
    	 System.out.println("hai");
     }

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
		
	static int a=9;
	
	static{
		System.out.println("Static Block gets executed first");
	}
	
	public int add(int a,int b)
	{
		int c=a+b;
		return c;
	}
	public static void main(String args[]){
		
		Sample s=new Sample();
		int b=s.age;
		System.out.println(b);
		int ab=s.add(29, 89);
		System.out.println(ab+"  Main method executes");
		System.out.println(a);

	}
	
	




}
