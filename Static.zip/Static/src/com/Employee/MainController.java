package com.Employee;

import java.util.Scanner;

public class MainController {
	public static void main(String args[]) {

		Scanner inp = new Scanner(System.in);
		System.out.print("Hey all! Enter the working hours to know your status of the week :");
		int a = inp.nextInt();

		Employee.setWorkingHours(a);

		inp.close();
	}

}
