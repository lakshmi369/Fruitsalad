package com.Employee;

public class ExceptionEx {
	
 //Case 1:For Runtym exception
	//static ArithmeticException ae=new ArithmeticException();
	//static ArithmeticException e;
 
 public static void main(String args[])throws InterruptedException
 
 {
	// throw ae;
	 //throw e;
	 
	//For Compile time exception
	// throw new ArithmeticException("/ by zero");
	 //System.out.println("Hello");
	 //Thread.sleep(100000);
	 
	 StringBuffer a=new StringBuffer("Hi how are you?");
	 System.out.println("String Before Reversing: "+a);
	 StringBuffer b=a.reverse();
	 System.out.println(b);
 }

}
