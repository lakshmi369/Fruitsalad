package com.Employee;

import java.util.ArrayList;
import java.util.List;

public class Main {
	
	
	/*public static void main(String[] args)
	{*/
		
		/*List<String> l=new ArrayList<String>();
		l.add("apple");
		l.add("apple");
		l.add("grapes");
		l.add("banana");
		int count=0;
		for(int i=0;i<l.size()-1;i++)
		{
			
				if(l.contains("apple"))
				{
					count++;
				}
			}
		
	System.out.println(count);	
	}
*/
	public static void main(String args) {
		//System.out.println("Hello");
		String a="Hello";
		String b=(a.substring(1))+a.charAt(0);
		System.out.println(b);
	
	}}