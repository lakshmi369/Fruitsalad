package com.Employee;

public class Sum {

	public static void sumOfn(int... x){
		int total=0;
		for(int y:x){
			total=total+y;
			}
		System.out.println("Sum is "+total);
	}
	
	
	public static void main(String[] args){
		
		sumOfn();
		sumOfn(19,56,75);
		sumOfn(56,78);
		sumOfn(43,23,12,78,98);
	}
	
	
}
