package com.Employee;
/*import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
*/import java.util.*;

public class ExList {
	public static void main(String args[]){
    HashMap<String,String> h=new HashMap<String,String> ();
    h.put("Apple", "a");
    h.put("Banana", "b");
    h.put("Grapes", "g");
    
    List<HashMap<String,String>> l=new LinkedList<HashMap<String,String>>(); 
    l.add(h);
    System.out.println(l);
    
}}
