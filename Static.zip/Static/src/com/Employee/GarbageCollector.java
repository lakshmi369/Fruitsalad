package com.Employee;
import static java.lang.System.out;
public class GarbageCollector {
 
	@Override 
	public void finalize(){
		out.println("System is garbage collected");
	}
	
	public static void main(String args[]){
		
		GarbageCollector g=new GarbageCollector();
		g=null;
		System.gc();
		
		//Example for String immutability
		String s="uthra";
	    s.concat("siva");
		System.out.println(s);
		
		//Example for String mutability
		StringBuffer st=new StringBuffer("uthra");
	    st.append("siva");
		System.out.println(st);
		
		//Example for == comparator
		String s1=new String("uthra");
		 s1=new String("uthra");
		
		System.out.println(s1.contentEquals(s1));
		
		
	}
}
