package com.StringReverse;

public class StringReverserWithoutRecursion {

	public String reverse(String st) {

		String res = "";
		for (int i = st.length() - 1; i >= 0; i--) {

			char a = st.charAt(i);
			res = res + a;

		}
		return res;
	}

	public static void main(String[] args) {

		StringReverserWithoutRecursion r = new StringReverserWithoutRecursion();
		String rev = r.reverse("Hello World");
		System.out.println("Reversing a String:"+rev);

	}

}
