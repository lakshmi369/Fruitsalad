package com.StringReverse;

import static java.lang.System.out;

import java.util.Scanner;

public class MainController {

	public static void main(String args[]) {
		out.println("Enter a string :");
		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		long start=System.currentTimeMillis();
		StringReverserWithRecursion r = new StringReverserWithRecursion();
		String st = r.reverse(a);
		System.out.println("Reverse String with Recursion: " + st);
		long stop=System.currentTimeMillis();
		long tot=stop-start;
		System.out.println(tot);

		long strt=System.currentTimeMillis();
		StringReverserWithoutRecursion s = new StringReverserWithoutRecursion();
		String str = s.reverse(a);
		System.out.println("Reverse String Without Recursion: " + str);
		long stp=System.currentTimeMillis();
		long total=stp-strt;
		System.out.println(total);

		sc.close();

	}
}
