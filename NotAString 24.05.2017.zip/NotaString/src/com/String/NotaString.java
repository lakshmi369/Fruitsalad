package com.String;

public class NotaString {

	String a = "Human being ";
	String str = "";

	public String notAdd(String word) {
		if (word.contains("not")) {
			str = word;
		} else {
			str = "not".concat(word);
		}
		return str;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		NotaString n = new NotaString();

		// Test Case 1:
		String str1 = n.notAdd(" " + "going to home");
		System.out.println(str1);

		// Test Case 2:
		String str2 = n.notAdd(" " + "a float number");
		System.out.println(str2);

		// Test Case 3:
		String str3 = n.notAdd("not an integer");
		System.out.println(str3);

	}

}
