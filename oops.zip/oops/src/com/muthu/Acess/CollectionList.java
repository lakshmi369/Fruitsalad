package com.muthu.Acess;


import java.util.*;


public class CollectionList {
	public static void main(String args[]){
	ArrayList<String> s=new ArrayList<String>();
	s.add("Muthu");
	s.add("uthra");
	ArrayList<String> s1=new ArrayList<String>();
    s1.add("sashi");
    s1.addAll(s);
	Iterator<String> itr=s1.iterator();
    while(itr.hasNext())
    	System.out.println(itr.next());
	}}
