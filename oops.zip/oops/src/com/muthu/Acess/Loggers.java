package com.muthu.Acess;

public class Loggers {
	/*
	 * private int ids;
	 * 
	 * protected int getlogID(int id) { return ids; }
	 */
	public static void main(String args[])

	{
		String a = "MuthuSubbulAkshmi";
		String b = a.substring(5).toUpperCase();
		System.out.println(b);
		
		
	}
}
