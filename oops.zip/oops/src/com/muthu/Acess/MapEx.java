package com.muthu.Acess;

import java.util.*;

public class MapEx {
	
	public static void main(String args[]){
		
		/*HashMap m=new HashMap();
		m.put("Muthu",1);
		m.put("uthra",17);
		m.put("Manisha",10);
		m.put("Manju",18);
		m.put("Moni",54);
		System.out.println(m);
		System.out.println(m.put("Muthu", 67));
		Set s=m.keySet();
		System.out.println(s);
		Collection c=m.values();
		System.out.println(c);
		Set s1=m.entrySet();
		System.out.println(s1);
		
		Iterator itr=s1.iterator();
		while(itr.hasNext())
		{
			Map.Entry m1=(Map.Entry)itr.next();
			System.out.println(m1.getKey()+" "+m1.getValue());
			if(m1.getKey().equals("Moni")){
				m1.setValue(6755);
			}
		}
		System.out.println(m);
*/	
		
	
	
	IdentityHashMap m=new IdentityHashMap();
	Integer i1=new Integer(8);
	Integer i2=new Integer(8);
	m.put(i1,"Muthu");
	m.put(i2,"Uthra");
	System.out.println(m);
	
	
	
	
	}

}
