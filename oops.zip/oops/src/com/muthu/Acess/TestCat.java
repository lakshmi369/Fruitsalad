package com.muthu.Acess;

public class TestCat {

	public static void main(String args[]) {

		Cat tc = new Cat();
		tc.setAge(4);
		tc.setName("Puppy");

		System.out.println("Name :" + tc.getName());
		System.out.println("Age :" + tc.getAge());

	}

}
