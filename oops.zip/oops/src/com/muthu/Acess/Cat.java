package com.muthu.Acess;

public class Cat {

	private int age;
	private String name;
	int highage=15;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		
		if(age>16)
		{
			age=highage;
		}
		this.age = age;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
