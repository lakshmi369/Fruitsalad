package com.muthu.Acess;
import java.util.*;

class Num{
	String firstname;
	String lastname;
	long num;
	
	public Num(long num,String firstname,String lastname)
	{
		this.num=num;
		this.firstname=firstname;
		this.lastname=lastname;
	}
}
public class ListEx {
	
	public static void main(String args[])
	{
		List<Num> list=new ArrayList<Num>();
		Num n1=new Num(924535673,"uthra","Shiva");
		Num n2=new Num(985677893,"sashi","saii");
	    
	list.add(n1);
	list.add(n2);
	
	for(Num n: list){
		System.out.println(n.num+" "+" "+ n.firstname+" "+n.lastname);
	}
	
	}
	
	

}
