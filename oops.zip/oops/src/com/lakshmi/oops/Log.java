package com.lakshmi.oops;

public class Log {
	
	
		   private String format;

		   public  String getFormat() {
		      return this.format;
		   }

		   public void setFormat(String format) {
		      this.format = format;
		   }
		}




