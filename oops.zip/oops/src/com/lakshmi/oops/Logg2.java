package com.lakshmi.oops;

public class Logg2 {
	
	public static void main(String args[])
	{
		Log a=new Log();
		
		a.setFormat("farmat");
		
		String b=a.getFormat();
		System.out.println(b);
		
		
		
	}

}
