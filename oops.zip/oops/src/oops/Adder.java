package oops;

import static java.lang.System.out;

public class Adder {
	int i;

	public static int addOne(int a) {
		return a;
	}

	public static void main(String[] args) {

		int a = 5;

		int result = Adder.addOne(a++);
		out.println(result);
		out.println(result++); 
		out.println(result++);
		++result;
	

		out.println("1: "+a--);
		 out.println("2: " +--a);
		 out.println("total "+a);
		 
		 if(a==4)
		 {
			 out.println("result is "+ a);
		 }
		 
		if (result == 8) {
			out.println("pass");
		} else {
			out.println("fail");
		}

	}

}
