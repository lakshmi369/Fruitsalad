package oops;

public class TestStatic {

	static {

		System.out.println("Hello");
	}

}
