
public class ExampleForStatic {

	private String name;
	private int Id;
	private static String collegeName = "";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public static String getCollegeName() {
		return collegeName;
	}

	public static void setCollegeName(String collegeName) {
		// using the class name the method is called instead of object
		ExampleForStatic.collegeName = collegeName;
	}

	public static void main(String args[]) {

		ExampleForStatic a = new ExampleForStatic();
		a.setName("Muthu");

		System.out.println("Name: " + a.getName());

		ExampleForStatic.setCollegeName("SRM");
		ExampleForStatic.setCollegeName("SS");
		System.out.println(ExampleForStatic.getCollegeName());
		System.out.println(ExampleForStatic.getCollegeName());

	}
}
