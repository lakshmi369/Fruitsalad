
//FINAL CLASS CANNOT BE EXTENDED
public class Ex extends ExampleForFinal {
	
//FINAL METHOD CANNOT BE OVERRIDE
	/*public int add(int a,int b)
	{
		int c=a+b;
		return c;
	}*/
	
	public static void main(String args[])
	{
		Ex a=new Ex();
		int b=a.add(10, 24);
		System.out.println("Add "+b);
	}

}
