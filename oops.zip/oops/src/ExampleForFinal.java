
public  class ExampleForFinal {
	
	private  static final  int HOURS_PER_DAY=24;
	

	public int getHoursPerDay() {
		return HOURS_PER_DAY;
	}

	public  final int add(int a,int b)
	{
		int c=a+b;
		return c;
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		//FINAL VALUE CANNOT BE CHANGED
		//HOURS_PER_DAY=90;
		
	System.out.println("HOURS_PER_DAY: "+HOURS_PER_DAY);
	ExampleForFinal a=new ExampleForFinal();
	int b=a.add(2,5);
	int c=a.add(67, 68);
	System.out.println("Add A "+b);
	System.out.println("Add B "+c);
	}

}
