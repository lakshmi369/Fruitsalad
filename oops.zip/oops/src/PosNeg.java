
public class PosNeg {

	public PosNeg() {

	}

	public static boolean posNeg(int a, int b, boolean result) {

		
		if ((a > 0 && b < 0) || result) {
			return true;
		} else if ((a < 0 && b > 0) || result==true) {
			return false;
		} else if ((a < 0 && b > 0) || result==false) {
			return true;
		} else if ((a < 0 && b < 0) || result) {
			return false;
		} else if ((a < 0 && b < 0) || result) {
			return true;
		} else if ((a < 0 && b > 0) || result) {
			return false;
		}
		
		return false;
		

	}

	public static void main(String ar[]) {

		int x = 0;
		int y = 0;
		boolean value = false;
         
		// Test #1

		x = 1;
		y = -1;
		value = false;

		value = PosNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("1.Test pass");

		} else {
			System.out.println("1.fails");
		}

		// Test #2

		x = -1;
		y = 1;
		value = false;

		value = PosNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("2.Test pass");

		} else {
			System.out.println("2.fails");
		}

		// Test #3

		x = 1;
		y = 1;

		value = false;

		value = PosNeg.posNeg(x, y, value);

		if (value == false) {
			System.out.println("3.Test pass");
		} else {
			System.out.println("3.fails");
		}

		// Test #4

		x = -1;
		y = -1;

		value = false;

		value = PosNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("4.Test pass");
		} else {
			System.out.println("4.fails");
		}

		// Test #5

		x = -1;
		y = -1;

		value = true;

		value = PosNeg.posNeg(x, y, value);

		if (value == true) {
			System.out.println("5.Test pass");
		} else {
			System.out.println("5.fails");
		}
		// Test #6

		x = -1;
		y = 1;

		value = true;

		value = PosNeg.posNeg(x, y, value);

		if (value == false) {
			System.out.println("6.Test pass");
		} else {
			System.out.println("6.fails");
		}
	

	}

}
