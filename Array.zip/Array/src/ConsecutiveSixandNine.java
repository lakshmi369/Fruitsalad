
import java.util.*;

class ConsecutiveSixandNine {

	public int consecNumbers(List<Integer> list, int number) {

		int n = list.size();
		int count = 0, noOfConsecutives = 0;
		boolean isConsecutiveBreak = true;
		for (int i = 0; i < n; i++) {
			if (list.get(i) == number) {
				count += 1;
			}

			if (list.get(i) == number && i + 1 < n && list.get(i + 1) == number) {
				noOfConsecutives += isConsecutiveBreak ? 2 : 1;
				isConsecutiveBreak = false;
			} else {
				isConsecutiveBreak = true;
			}
		}
		return noOfConsecutives;

	}

	public static void main(String args[]) {

		Integer[] val = new Integer[] { 2, 9, 9, 9, 9, 7, 6, 6, 4, 6, 8, 6, 6, 6, 9, 9, 7, 9, 6, 9 };
		ArrayList<Integer> ar = new ArrayList<Integer>(Arrays.asList(val));
		ConsecutiveSixandNine c = new ConsecutiveSixandNine();

		int d = c.consecNumbers(ar, 6);
		int e = c.consecNumbers(ar, 9);

		// Test Case:
		if (d == 5 && e == 6) {
			System.out.println("Test Pass");

		} else {
			System.out.println("Test fails");
		}
	}

}
