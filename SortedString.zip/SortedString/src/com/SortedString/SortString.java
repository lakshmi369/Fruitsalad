package com.SortedString;

public class SortString {

	/*
	 * public String reverse(){ String a1="muthu"; for(int
	 * i=a1.length()-1;i>=0;i--){ System.out.println(a1.charAt(i)); }
	 * 
	 * 
	 * return a1; }
	 */

	public String reverse(){
	String str="FULL CREATIVE";
	 String sorted=""; char[] ch=str.toCharArray();
	   for(int i=0;i<ch.length;i++) 
	   { 
		   for(int j=0;j<ch.length;j++)
	   {
			   if(ch[i] <ch[j]) 
	   {
		   char temp = ch[i]; 
		   ch[i]=ch[j];
		   ch[j]=temp;
		   } } }
	   for(int k=0;k<ch.length;k++) 
	   { 
		   sorted=sorted+ch[k];
	  
	  } 
	   
	  return sorted;
	  } 
			
		
		public static void main(String args[]){  
		
		 SortString str=new SortString();
		 String rev=str.reverse();
		 System.out.println("String Before getting Alphabetical order:FULL CREATIVE");
		 System.out.println("String After getting  Alphabetical order: "+rev);

			}}