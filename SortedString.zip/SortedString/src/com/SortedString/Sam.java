package com.SortedString;

class Sam extends Ex {
	
	Sam()
	{
		super.printNum(56);

	}
	public static void printNum(int b) {
		System.out.println(b);

	}

	public void print() {
		System.out.println("hai");
	}

	public void show(final int a) {
		//super.printNum(56);
System.out.println(a);
				print();
				
	}

	public static void main(String args[]) {

		Sam s = new Sam();
		Sam.printNum(67);
		s.show(10);
		final int a;
		
		System.out.println();

	}
}
