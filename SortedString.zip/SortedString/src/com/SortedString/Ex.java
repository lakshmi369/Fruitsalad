package com.SortedString;

public class Ex {
	
	public static void printNum(int a){
		System.out.println(a);
	}
	
	
	/*//System.out.println("Main method");

public static void main(int args[]){
	System.out.println("overloaded");
}
Integer a=new Integer(90);
//a=98;
//String a="56";
//int b=Integer.parseInt(a);
//System.out.println(a);
*/


}
