import java.util.*;
public class TreeSetDemo {
	
	public static void main(String args[])
	
	{
		
		HashSet s=new HashSet();
		s.add(101);
		s.add(90);
		s.add(90);
		//s.add(null);
		
		s.add("h");
		
System.out.println(s);
				
	
	
	

}
}
