package com.Multiple;

import java.util.Scanner;

public class MainController {

	public static void main(String args[]) {

		System.out.print("Enter an Integer: ");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		boolean res = MultipleOf3Or5.multipleOf3Or5Only(a);

		if (res == true) {
			System.out.println("MultipleOf3Or5Only(" + a + ") --> True");
		} else {
			System.out.println("Not a multiple of 3 or 5");
		}

		sc.close();

	}

}
